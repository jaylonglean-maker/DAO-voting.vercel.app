# DAO Voting Playground

This is a demo React app (Create React App style) that simulates several DAO voting mechanisms:
- Token-based quorum voting
- Quadratic voting
- Weighted voting
- Reputation-based voting

It includes a simple MetaMask integration (ethers.js) to simulate a wallet casting a vote.

## Run locally

```
npm install
npm start
```

## Notes

- This demo simulates wallet votes and does not submit transactions on-chain.
- Tailwind classes are present in the UI code but this starter uses minimal CSS (white theme).
