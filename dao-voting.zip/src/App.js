import React, { useState, useMemo, useEffect } from 'react';
import { ethers } from 'ethers';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';

// Simplified DAO Voting Playground with specific mechanisms:
// Token-based quorum voting, Quadratic voting, Weighted voting, Reputation-based voting.
// Added MetaMask wallet integration: connect wallet, show address and ETH balance,
// and allow the connected wallet to cast a vote (simulated off-chain for this demo).

function computeTokenQuorum(votes, proposals, quorum = 0.5) {
  const tally = Object.fromEntries(proposals.map((p) => [p.id, 0]));
  const totalTokens = votes.reduce((acc, v) => acc + (v.tokens ?? 0), 0);
  votes.forEach((v) => {
    tally[v.proposalId] += v.tokens ?? 0;
  });
  // Filter proposals below quorum
  for (const key in tally) {
    if (tally[key] < totalTokens * quorum) tally[key] = 0;
  }
  return tally;
}

function computeQuadraticVoting(votes, proposals) {
  const tally = Object.fromEntries(proposals.map((p) => [p.id, 0]));
  votes.forEach((v) => {
    tally[v.proposalId] += Math.sqrt(v.creditsSpent ?? 0);
  });
  return tally;
}

function computeWeightedVoting(votes, proposals) {
  const tally = Object.fromEntries(proposals.map((p) => [p.id, 0]));
  votes.forEach((v) => {
    tally[v.proposalId] += v.weight ?? 1;
  });
  return tally;
}

function computeReputationVoting(votes, proposals) {
  const tally = Object.fromEntries(proposals.map((p) => [p.id, 0]));
  votes.forEach((v) => {
    tally[v.proposalId] += (v.reputation ?? 1) * (v.support ? 1 : -1);
  });
  return tally;
}

function generateVoters(n) {
  return Array.from({ length: n }).map((_, i) => ({
    id: `v${i + 1}`,
    tokens: Math.floor(Math.random() * 100) + 1,
    weight: Math.floor(Math.random() * 10) + 1,
    creditsSpent: Math.floor(Math.random() * 16),
    reputation: Math.floor(Math.random() * 5) + 1,
  }));
}

export default function DAOVotingPlayground() {
  const [proposals, setProposals] = useState([
    { id: 'p1', title: 'Grant funding for research' },
    { id: 'p2', title: 'Increase treasury allocation' },
    { id: 'p3', title: 'Appoint a new council' },
  ]);

  const [mechanism, setMechanism] = useState('token-quorum');
  const [voterCount, setVoterCount] = useState(20);
  const [voters, setVoters] = useState(() => generateVoters(20));
  const [votes, setVotes] = useState([]);

  // Wallet state
  const [wallet, setWallet] = useState({ connected: false, address: null, chainId: null, ethBalance: 0 });

  useEffect(() => {
    // If MetaMask is available and the user switches accounts or networks, update state
    if (typeof window !== 'undefined' && window.ethereum) {
      window.ethereum.on && window.ethereum.on('accountsChanged', (accounts) => {
        if (accounts.length === 0) {
          setWallet({ connected: false, address: null, chainId: null, ethBalance: 0 });
        } else {
          // Reconnect to the first account
          connectWallet().catch(() => {});
        }
      });
      window.ethereum.on && window.ethereum.on('chainChanged', () => {
        connectWallet().catch(() => {});
      });
    }
    // cleanup handled by framework when component unmounts
  }, []);

  async function connectWallet() {
    try {
      if (!window.ethereum) throw new Error('MetaMask not installed');
      const provider = new ethers.providers.Web3Provider(window.ethereum, 'any');
      await provider.send('eth_requestAccounts', []);
      const signer = provider.getSigner();
      const address = await signer.getAddress();
      const network = await provider.getNetwork();
      const rawBalance = await provider.getBalance(address);
      const ethBalance = parseFloat(ethers.utils.formatEther(rawBalance));
      setWallet({ connected: true, address, chainId: network.chainId, ethBalance });
    } catch (err) {
      console.error('connectWallet error', err);
      setWallet({ connected: false, address: null, chainId: null, ethBalance: 0 });
      alert(err.message || String(err));
    }
  }

  function disconnectWallet() {
    setWallet({ connected: false, address: null, chainId: null, ethBalance: 0 });
  }

  function regenerateVoters(count) {
    setVoters(generateVoters(count));
  }

  function autofillVotes() {
    const newVotes = voters.map((v, i) => ({
      voterId: v.id,
      proposalId: proposals[i % proposals.length].id,
      tokens: v.tokens,
      creditsSpent: v.creditsSpent,
      weight: v.weight,
      reputation: v.reputation,
      support: Math.random() > 0.3,
    }));
    setVotes(newVotes);
  }

  // Allow the connected wallet to cast a simple vote (simulated off-chain).
  // For token-quorum it uses scaled ETH balance as tokens; for quadratic it spends credits;
  // for weighted/reputation it uses defaults derived from wallet.ethBalance as well.
  function castWalletVote(proposalId) {
    if (!wallet.connected || !wallet.address) {
      alert('Connect wallet first');
      return;
    }
    const voterId = wallet.address.toLowerCase();
    // scale ETH balance to an integer token-like amount for demo purposes
    const tokens = Math.max(1, Math.floor(wallet.ethBalance * 10));
    const creditsSpent = Math.min(25, Math.floor(wallet.ethBalance * 3));
    const weight = Math.max(1, Math.floor(wallet.ethBalance * 2));
    const reputation = Math.max(1, Math.floor(Math.min(10, wallet.ethBalance * 1.5)));

    setVotes((prev) => {
      // replace existing vote by same voter if present
      const others = prev.filter((v) => v.voterId !== voterId);
      return [
        ...others,
        {
          voterId,
          proposalId,
          tokens,
          creditsSpent,
          weight,
          reputation,
          support: true,
        },
      ];
    });
  }

  const outcome = useMemo(() => {
    if (mechanism === 'token-quorum') return computeTokenQuorum(votes, proposals);
    if (mechanism === 'quadratic') return computeQuadraticVoting(votes, proposals);
    if (mechanism === 'weighted') return computeWeightedVoting(votes, proposals);
    if (mechanism === 'reputation') return computeReputationVoting(votes, proposals);
    return {};
  }, [mechanism, votes, proposals]);

  const chartData = proposals.map((p) => ({ name: p.title, votes: outcome[p.id] ?? 0 }));

  // Determine winning proposal for the summary (largest score)
  const winner = React.useMemo(() => {
    let best = null;
    let bestScore = -Infinity;
    for (const p of proposals) {
      const s = outcome[p.id] ?? 0;
      if (s > bestScore) {
        bestScore = s;
        best = { ...p, score: s };
      }
    }
    return best;
  }, [outcome, proposals]);

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">DAO Voting Playground</h1>
            <p className="text-sm text-slate-600">Experiment with Token-based Quorum, Quadratic, Weighted, and Reputation voting mechanisms.</p>
          </div>

          <div className="text-right">
            {wallet.connected ? (
              <div className="text-sm">
                <div>Connected: <span className="font-mono">{wallet.address}</span></div>
                <div>ETH balance: {wallet.ethBalance.toFixed(4)}</div>
                <div>Chain ID: {wallet.chainId}</div>
                <button onClick={disconnectWallet} className="mt-2 px-3 py-1 rounded bg-rose-600 text-white text-xs">Disconnect</button>
              </div>
            ) : (
              <div>
                <button onClick={connectWallet} className="px-3 py-2 rounded-md bg-emerald-600 text-white">Connect MetaMask</button>
              </div>
            )}
          </div>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2 bg-white p-4 rounded-2xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <label className="block text-sm font-medium text-slate-700">Voting Mechanism</label>
                <select
                  value={mechanism}
                  onChange={(e) => setMechanism(e.target.value)}
                  className="mt-1 block w-full border rounded-md p-2"
                >
                  <option value="token-quorum">Token-based Quorum Voting</option>
                  <option value="quadratic">Quadratic Voting</option>
                  <option value="weighted">Weighted Voting</option>
                  <option value="reputation">Reputation-based Voting</option>
                </select>
              </div>

  <div className="w-48">
    <label className="block text-sm font-medium text-slate-700">Voters</label>
    <div className="flex gap-2 mt-1">
      <input
        type="number"
        min={1}
        value={voterCount}
        onChange={(e) => setVoterCount(Number(e.target.value))}
      className="w-20 border rounded-md p-2"
      />
      <button onClick={() => regenerateVoters(voterCount)} className="px-3 py-2 rounded-md bg-slate-800 text-white">
        Regenerate
      </button>
    </div>
  </div>

            </div>

            <div className="mb-4">
              <h3 className="font-semibold">Proposals</h3>
              <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-2">
                {proposals.map((p) => (
                  <div key={p.id} className="p-3 border rounded-md bg-slate-50">
                    <div className="font-medium">{p.title}</div>
                    <div className="text-xs text-slate-500 mt-1">ID: {p.id}</div>
                    {wallet.connected && (
                      <div className="mt-2 flex gap-2">
                        <button onClick={() => castWalletVote(p.id)} className="px-2 py-1 text-xs rounded bg-indigo-600 text-white">Cast wallet vote</button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-4">
              <h3 className="font-semibold">Simulator Controls</h3>
              <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-2">
                <button onClick={autofillVotes} className="px-3 py-2 rounded-md bg-indigo-600 text-white">
                  Autofill Votes
                </button>
                <button onClick={() => setVotes([])} className="px-3 py-2 rounded-md bg-rose-600 text-white">
                  Clear Votes
                </button>
                <button
                  onClick={() => {
                    // quick helper: if wallet connected, add a wallet-based vote to proposal 1
                    if (wallet.connected) castWalletVote(proposals[0].id);
                    else alert('Connect wallet to use wallet-based actions');
                  }}
                  className="px-3 py-2 rounded-md bg-emerald-600 text-white"
                >
                  Use Wallet for Proposal 1
                </button>
              </div>
            </div>

            <div className="mt-4 bg-gradient-to-r from-white to-slate-50 p-3 rounded-xl border">
              <h4 className="font-semibold mb-2">Results</h4>
              <div className="w-full" style={{ height: 280 }}>
                <ResponsiveContainer>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="votes" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <table className="w-full text-sm mt-3 table-auto">
                <thead>
                  <tr className="text-left text-xs text-slate-500">
                    <th className="py-1">Proposal</th>
                    <th className="py-1">Score</th>
                  </tr>
                </thead>
                <tbody>
                  {proposals.map((p) => (
                    <tr key={p.id} className="border-t">
                      <td className="py-2">{p.title}</td>
                      <td className="py-2 font-medium">{(outcome[p.id] ?? 0).toFixed(3)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Results summary */}
              <div className="mt-4 p-3 border rounded-md bg-slate-50">
                <div className="text-sm text-slate-600">Winning proposal:</div>
                {winner ? (
                  <div className="mt-1 font-semibold">{winner.title} — score {winner.score.toFixed(3)}</div>
                ) : (
                  <div className="mt-1">No votes yet</div>
                )}
              </div>
            </div>
          </div>

          <aside className="bg-white p-4 rounded-2xl shadow-sm">
            <h3 className="font-semibold">Mechanism Info</h3>
            <div className="mt-2 text-sm text-slate-600 space-y-3">
              {mechanism === 'token-quorum' && (
                <p>
                  <strong>Token-based Quorum Voting:</strong> Voters use governance tokens to vote. Proposals must reach a certain quorum to be valid.
                </p>
              )}
              {mechanism === 'quadratic' && (
                <p>
                  <strong>Quadratic Voting:</strong> Influence grows with the square root of tokens or credits spent, encouraging balanced decision-making.
                </p>
              )}
              {mechanism === 'weighted' && (
                <p>
                  <strong>Weighted Voting:</strong> Voting power depends on stake or contribution level.
                </p>
              )}
              {mechanism === 'reputation' && (
                <p>
                  <strong>Reputation-based Voting:</strong> Voters’ influence depends on their on-chain or community reputation scores.
                </p>
              )}
            </div>
          </aside>
        </section>
      </div>
    </div>
  );
}
